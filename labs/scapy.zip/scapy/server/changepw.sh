#!/bin/bash

set -e

echo "root:password" | chpasswd
