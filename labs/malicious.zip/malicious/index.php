<?php
    echo "<html>";
    echo "<h1>Welcome to the boring internal corporate website</h1>";
    echo "<div>Today's cafeteria lunch is: burnt toast and sorrow</div>";
    echo "<a href=\"timeoff.html\">Click here to schedule time off</a>";
?>
